/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Model.Map;
import Vista.Ventana;
import javax.swing.JOptionPane;
/**
 *
 * @author DEVIN ALZATE
 */
public class Controller {
    Ventana ventana;

    public Controller() {
        ventana = new Ventana();
        ventana.setVisible(true);
    }
    
}
